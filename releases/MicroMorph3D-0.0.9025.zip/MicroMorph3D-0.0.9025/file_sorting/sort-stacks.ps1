# sort-stacks.ps1
# Sortiert Dateien wie x_y_z.ext in Ordner x_y (mit Support für negative Zahlen)

param(
    [string]$Path = ".",
    [switch]$Recurse,           # optional: auch Unterordner durchsuchen
    [switch]$WhatIf             # optional: nur anzeigen, nichts verschieben
)

# Bildformate anpassen, falls nötig
$exts = "jpg","jpeg","png","tif","tiff","bmp","gif"

# Regex:  x_y_z  jeweils ganze Zahl, Minus erlaubt
# Beispiel passt: 14_-40_282.jpg  -> x=14, y=-40
$pattern = '^(?<x>-?\d+)_(?<y>-?\d+)_(?<z>-?\d+)(?:$|_)'

$searchParams = @{
    Path  = $Path
    File  = $true
    Recurse = [bool]$Recurse
}

Get-ChildItem @searchParams | Where-Object {
    # nur gewünschte Extensions
    $exts -contains $_.Extension.TrimStart('.').ToLower()
} | ForEach-Object {
    $name = $_.BaseName

    if ($name -match $pattern) {
        $x = $Matches['x']
        $y = $Matches['y']
        $dest = Join-Path -Path $Path -ChildPath ("{0}_{1}" -f $x, $y)

        if (-not (Test-Path -LiteralPath $dest)) {
            if ($WhatIf) {
                Write-Host "[WhatIf] New-Item -ItemType Directory -Path $dest"
            } else {
                New-Item -ItemType Directory -Path $dest | Out-Null
            }
        }

        $target = Join-Path -Path $dest -ChildPath $_.Name
        if ($WhatIf) {
            Write-Host "[WhatIf] Move-Item `"$($_.FullName)`" `"$target`""
        } else {
            Move-Item -LiteralPath $_.FullName -Destination $dest -Verbose
        }
    } else {
        Write-Host "Übersprungen (passt nicht zu x_y_z): $($_.Name)"
    }
}
